require "application_system_test_case"

class TeamsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit teams_url
  #
  #   assert_selector "h1", text: "Team"
  # end
end
