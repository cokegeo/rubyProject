# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
rails s                                                     to start the server
rails g scaffold Project name:string description:text       to generate a table (g = generate)
rails/rake db:migration                                     to migrate the DB
rails/rake db:rollback                                      to roll back the last db migrated for fixing issues
bundle install                                              to install gems from Gemfile
bundle update                                               to update the gems
gem install <gemName>                                       to install gems



To install gems used following website:                     https://rubygems.org/
Used for stylesheet_link_tag                                http://tachyons.io/docs/
To insert logo image_tag                                    https://apidock.com/rails/ActionView/Helpers/AssetTagHelper/image_tag
